from lxml import etree

tree = etree.parse('task1.xml')

for item in tree.xpath('//page'):
    subfields = item.getchildren()
    # print len(subfields)
    count = len([subfield.attrib["type"] for subfield in subfields if subfield.attrib["type"] == "text"])
    # count1 = len([subfield.attrib["type"] for subfield in subfields if subfield.attrib["type"] == "image"])
    print item.attrib["url"], " - ", count
    # print count1
        # for attr in subfield.attrib:
        #     print subfield.attrib[attr]
