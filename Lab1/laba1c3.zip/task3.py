from lxml import html
from lxml import etree
import requests

page = requests.get('http://hotline.ua/bt/holodilniki/')
tree = html.fromstring(page.content)

links = tree.xpath('//b[@class="m_r-10"]/a/@href')

root = etree.Element('data')
doc = etree.ElementTree(root)

page_element = etree.SubElement(root, 'page',
                                     url="http://hotline.ua/bt/holodilniki/")

for i in range(1, 21):
    page = requests.get('http://hotline.ua' + links[i])
    tree = html.fromstring(page.content)
    name = tree.xpath('//h1[@class="title-24 p_b-5"]/text()')
    # print name[1]
    description = tree.xpath('//p[@class="full-desc text-14"]/text()')
    image = tree.xpath('//img[@class="max-250 ma p_r-15 g_statistic"]/@src')

    product_element = etree.SubElement(root, 'product')
    name_element = etree.SubElement(product_element, 'title')
    name_element.text = name[1]
    desc_element = etree.SubElement(product_element, 'description')
    desc_element.text = description[0]
    image_element = etree.SubElement(product_element, 'image')
    image_element.text = image[0]

doc.write('task3.xml', xml_declaration=True, encoding='utf-8')

